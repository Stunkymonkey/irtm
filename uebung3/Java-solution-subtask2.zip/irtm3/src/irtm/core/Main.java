package irtm.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;

import org.ejml.data.DMatrixRMaj;
import org.ejml.simple.SimpleMatrix;

public class Main {

	///////////////////////////////////
	// CLASS DEFINITIONS //////////////
	///////////////////////////////////

	/**
	 * Postingslist storing (unique) document IDs in ascending order.
	 * @param <T> the document ID type
	 */
	static class PostingsList<T extends Comparable<T>> implements Iterable<T> {
		/**
		 * map from document id to number of occurrences (TF) of the respective posting in that document.
		 * The int[] is always of length 1 and the value at index 0 is the number of occurrences
		 * (instead of using Integer for convenience of incrementing).
		 */
		private Map<T, int[]> docid2termfreq;

		public PostingsList(boolean isFrequentWord) {
			docid2termfreq = new TreeMap<>();
		}

		public PostingsList() {
			this(false);
		}

		public Iterator<T> iterator() {
			return docid2termfreq.keySet().iterator();
		}

		public int size() {
			return docid2termfreq.size();
		}

		public synchronized int add(T e) {
			if(!docid2termfreq.containsKey(e)){
				// add as new document
				docid2termfreq.put(e, new int[]{0});
			}
			// increment term frequency for this document
			return ++docid2termfreq.get(e)[0];
		}

		public int getTF(T docid){
			if(!docid2termfreq.containsKey(docid)){
				return 0;
			}
			return docid2termfreq.get(docid)[0];
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("Postings[");
			Iterator<T> iter = iterator();
			while(iter.hasNext()){
				sb.append(iter.next());
				if(iter.hasNext()){
					sb.append(", ");
				}
			}
			sb.append("]");
			return sb.toString();
		}

	}

	/**
	 * Tweet class containing the meta data and tweet text
	 * @param <T> the document ID type
	 */
	static class Tweet<T> {
		T id;
		String date;
		String authorid;
		String authorname;
		String text;

		public Tweet(T id, String date, String authorid, String authorname, String text) {
			super();
			this.id = id;
			this.date = date;
			this.authorid = authorid;
			this.authorname = authorname;
			this.text = text;
		}

		@Override
		public String toString() {
			return String.format("Tweet[%s] from %s by %s%n\t%s", id,date,authorid,text);
		}
	}

	/**
	 * Single method interface (like a 5-consumer) that provides the
	 * {@link TweetProcessor#accept(long, String, String, String, String)} method
	 * and is used to define a processing for a single tweet.
	 */
	static interface TweetProcessor {
		/**
		 * processes a tweet (tweet is defined by all parameters id, date, userId, userName, text)
		 */
		public void accept(long id, String date, String userId, String userName, String text);

		/** processes a tweet */
		default void accept(Tweet<Long> tweet){
			accept(tweet.id, tweet.date, tweet.authorid, tweet.authorname, tweet.text);
		}
		/**
		 * returns a new processor that first executes this one and then the specified one.
		 * @param other tweet processor to be executed after this one
		 * @return concatenated tweet processors
		 */
		default TweetProcessor andThen(TweetProcessor other){
			TweetProcessor me = this;
			return (id,date,userId,userName,text)->{
				me.accept(id, date, userId, userName, text);
				other.accept(id, date, userId, userName, text);
			};
		}
	}

	/**
	 * Just a Runnable interface with Exception throwing declaration.
	 * Used in conjunction with {@link Main#wrapRTE(ThrowingRunnable)}.
	 */
	static interface ThrowingRunnable {
		public void run() throws Exception;
	}

	///////////////////////////////////
	// FIELDS /////////////////////////
	///////////////////////////////////

	/** the index (mapping from term to postingslist) */
	static Map<String, PostingsList<Long>> index = new ConcurrentHashMap<>();

	/** the documents (mapping from doc id to text) */
	static Map<Long, Tweet<Long>> documents = new ConcurrentHashMap<>();

	/** print stream for outputting, can also print to file */
	static PrintStream out = System.out;

	/** most frequent words, used to allocate more space in advance for frequent tokens */
	static List<String> mostfrequentwords = Arrays.asList("a","i","the","you","and","to","of","in");

	///////////////////////////////////
	// METHODS ////////////////////////
	///////////////////////////////////

	/** MAIN MEHTOD */
	public static void main(String[] args) throws Exception {

		/* INDEX TWEETS (and do other things as well)*/
		AtomicInteger numProcessedLines = new AtomicInteger();
		/* for all lines in tweets file : */
		iterateLinesParallel(new File("files/tweets.gz"), 16, (linenum,line)->{
//			if(linenum > 300000) return;
			/* define tweet processing task */
			TweetProcessor tweetprocessor = (id, date, uid, uname, text)->{
				BiConsumer<Long, List<String>> tokenIndexer = Main::indexTokens;
				/* generate tokens from text */
				processTextAsTokens(text, id, tokenIndexer);
			};
			/* define tweet storing task */
			TweetProcessor tweetstorer = Main::storeTweet;
			/* process and store each tweet */
			processLineAsTweet(linenum, line, tweetprocessor.andThen(tweetstorer));
			int numprocessed = numProcessedLines.incrementAndGet();
			if(numprocessed % 10000 == 0){
				System.out.println("processed " + numprocessed + " lines");
			}
		});
		System.out.println("index contains " + index.size() + " tokens");

		/* MAKE BOOLEAN QUERY */
		String t1 = "Stuttgart";
		String t2 = "Bahn";
		Iterable<Long> ids = query(t1,t2);
		out.println("Documents that contained " + t1 + " and " + t2);
		printDocuments(ids, -1);

		/* MAKE RANKED QUERY */
		String querytext = "baseball sings skyscraper";
		List<Entry<Long,Double>> rankedIds = rankedQuery(querytext);
		List<Long> idsRankDescending = rankedIds.stream().map(e->e.getKey()).collect(Collectors.toList());
		out.println();
		out.println("Rank descending documents for query: " + querytext);
		printDocuments(idsRankDescending, 10);
	}

	/**
	 * Makes a ranked query on the index based on cosine similarity
	 * to the query text.
	 * The specified text is tokenized and used in a boolean retrieval
	 * of all its word pairs.
	 * The retrieved documents are then ranked using cosine similarity
	 * of tf.idf vectors in the term space of the query text.
	 * @param text of query
	 * @return list of (docId, score) pairs in descending score order.
	 * score is in [0.0, 1.0]
	 */
	static List<Map.Entry<Long, Double>> rankedQuery(String text){
		// tokenize query text and normalize tokens
		List<String> tokens = tokenize(text);
		tokens = tokens.stream().map(Main::normalize).collect(Collectors.toList());
		// create local index of this document to calculate document frequencies of the query text
		HashMap<String, int[]> localindex = new HashMap<>();
		tokens.forEach(token->{
			if(!localindex.containsKey(token)){
				localindex.put(token, new int[]{0});
			}
			// increment term frequency
			localindex.get(token)[0]++;
		});
		// calc tf.idf vector for query (vector is in space of query terms)
		String[] terms = localindex.keySet().toArray(new String[localindex.size()]);
		SimpleMatrix q_tfidf = vector(terms.length);
		for(int i = 0; i < terms.length; i++){
			String term = terms[i];
			int tf = localindex.get(term)[0];
			int df = getDF(term);
			int n = documents.size();
			q_tfidf.set(i, calcTF_IDF(tf, df, n));
		}
		// normalize (and transpose in advance for later scalar product calc)
		q_tfidf = normalize(q_tfidf).transpose();
		return rankedQuery(q_tfidf, terms);
	}

	/**
	 * Does a ranked query on the index based on cosine similarity to the specified
	 * tf.idf vector. All documents containing at least one term pair from the set of
	 * specified terms are ranked using cosine similarity of tf.idf vectors in the
	 * term space of the specified term set.
	 * @param q_tfidf tf.idf vector with each entry corresponding to the term at the
	 * same index in the terms argument
	 * @param terms array of unique terms
	 * @return list of (docId, score) pairs in descending score order.
	 * score is in [0.0, 1.0]
	 */
	static List<Map.Entry<Long, Double>> rankedQuery(SimpleMatrix q_tfidf, String... terms){
		if(terms.length == 0){
			throw new IllegalArgumentException("cannot query with empty term set");
		}

		HashSet<Long> docs = new HashSet<>();
		if(terms.length == 1){
			// when only a single term is queried
			query(terms[0]).forEach(docs::add);
		}
		// boolean retrieval for all term pairs (e.g. [t1&t2],[t1&t3],[t2&t3],...)
		for(int i = 0; i < terms.length-1; i++){
			for(int j = i+1; j < terms.length; j++){
				query(terms[i],terms[j]).forEach(docs::add);
			}
		}
		// calculate tf.idf vector for each document and calculate rank
		Map<Long, Double> doc2score = new TreeMap<>();
		for(Long docid : docs){
			SimpleMatrix d_tfidf = normalize(getTF_IDF_vec(docid, terms));
			double cosine = q_tfidf.mult(d_tfidf).get(0);
			doc2score.put(docid, cosine);
		}
		// build score descending list
		Comparator<Map.Entry<Long, Double>> entrycomparator = (e1,e2)->{
			return (int)Math.signum(e2.getValue()-e1.getValue());
		};
		List<Map.Entry<Long, Double>> scoreDescendingIds = new ArrayList<>();
		doc2score.entrySet().forEach(entry->{
			int insert = Collections.binarySearch(scoreDescendingIds, entry, entrycomparator);
			if(insert < 0) {
				insert = -insert -1;
			}
			scoreDescendingIds.add(insert, entry);
		});
		return scoreDescendingIds;
	}

	/** @return document frequency (of index) for term */
	static int getDF(String term){
		PostingsList<Long> postingsList = index.get(term);
		return postingsList == null ? 0:postingsList.size();
	}

	/** @return term frequency for docuemnt and term */
	static int getTF(String term, Long docid){
		PostingsList<Long> postingsList = index.get(term);
		return postingsList == null ? 0:postingsList.getTF(docid);
	}

	/**
	 * @param term
	 * @param docid
	 * @return the tf.idf for specified term of specified document
	 */
	static double getTF_IDF(String term, Long docid){
		double tf = getTF(term, docid);
		double df = getDF(term);
		double n = documents.size();
		return calcTF_IDF(tf, df, n);
	}

	/**
	 * Calculates tf.idf (inverse document frequency weighted term frequency)
	 * @param tf term frequency
	 * @param df document frequency
	 * @param n number of documents
	 * @return tf.idf
	 */
	static double calcTF_IDF(double tf, double df, double n){
		if(df == 0 || tf == 0)
			return 0;
		return (1+Math.log(tf))*Math.log(n/df);
	}

	/**
	 * Returns a tf.idf vector for the specified document in the index
	 * in the term space specified by the terms argument
	 * @param docId of the document
	 * @param terms of the term space the vector is calculated in
	 * @return tf.idf vector with each entry corresponding to
	 * tf.idf of document for term in term array.
	 */
	static SimpleMatrix getTF_IDF_vec(Long docId, String... terms){
		double[] vec = new double[terms.length];
		for(int i = 0; i < terms.length; i++){
			vec[i] = getTF_IDF(terms[i], docId);
		}
		return vector(vec.length, vec);
	}

	/**
	 * Iterates all line of the gzipped tweets file and applies the specified
	 * line processor to it. Each line of the file consists of date, tweet id, user id,
	 * user name, tweet text (each delimited by tab).
	 * @param tweets gzipped tweets file
	 * @param lineProcessor function taking line number and text as arguments
	 * @throws Exception when something goes wrong.
	 */
	static void iterateLines(File tweets, BiConsumer<Integer,String> lineProcessor) throws Exception {
		FileInputStream fis = new FileInputStream(tweets);
		Scanner sc = new Scanner(tweets.getName().endsWith(".gz") ? new GZIPInputStream(fis):fis);
		int linenum = 0;
		while(sc.hasNextLine()){
			linenum++;
			String line = sc.nextLine();
			lineProcessor.accept(linenum, line);
		}
		sc.close();
	}

	/**
	 * same as {@link #iterateLines(File, BiConsumer)} but in parallel.
	 * @param tweets gzipped tweets file
	 * @param numTaks number of parallel tasks
	 * @param lineProcessor function taking line number and text as arguments
	 * @throws Exception when something goes wrong
	 */
	static void iterateLinesParallel(File tweets, int numTaks, BiConsumer<Integer,String> lineProcessor) throws Exception {
		Runnable[] tasks = new Runnable[numTaks];
		for(int i = 0; i < numTaks; i++){
			int j = i;
			tasks[i] = wrapRTE(()->iterateLines(tweets, (num,line)->{
				/* only process line when it is for the j-th task */
				if(num%numTaks == j)
					lineProcessor.accept(num, line);
			}));
		}
		Arrays.stream(tasks).parallel().forEach(Runnable::run);
	}

	/** wrap throwing code with runtime exception throwing wrapper */
	static Runnable wrapRTE(ThrowingRunnable r){
		return () -> {
			try{
				r.run();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		};
	}

	/**
	 * Splits a line of the tweets.gz file (a tweet) and splits it in its parts
	 * which will then be processed by the specified {@link TweetProcessor}.
	 * @param linenum number of line in tweets file
	 * @param line the line string
	 * @param tweetprocessor to process the fields of the tweet
	 */
	static void processLineAsTweet(int linenum, String line, TweetProcessor tweetprocessor){
		String[] columns = line.split("\t", -1);

		if(columns.length < 5){
			System.err.format("bad line at %d%n\t%s%n", linenum, line);
			return;
		}

		// get data from line
		String date = columns[0];
		long id = Long.parseLong(columns[1]);
		String userId = columns[2];
		String userName = columns[3];
		String text = columns[4];
		// process the tweet
		tweetprocessor.accept(id, date, userId, userName, text);
	}

	/**
	 * Stores the specified tweet in the {@link #documents} map.
	 * @param id of tweet
	 * @param date of tweet
	 * @param userId of tweet author
	 * @param userName of tweet author
	 * @param text of tweet
	 */
	static void storeTweet(long id, String date, String userId, String userName, String text){
		documents.put(id, new Tweet<Long>(id, date, userId, userName, text));
	}

	/**
	 * splits specified text into tokens which are then processed by the specified
	 * tokenprocessor (biconsumer of (docId,list[tokens])
	 * @param text to be tokenized
	 * @param documentID of the text
	 * @param tokenProcessor that processes the tokens
	 */
	static void processTextAsTokens(String text, long documentID, BiConsumer<Long, List<String>> tokenProcessor){
		// extract tokens
		List<String> tokens = tokenize(text);
		// normalize tokens
		List<String> normalizedTokens = tokens
				.stream()
				.map(String::trim)
				.map(Main::normalize)
				.filter(s->!s.isEmpty())
				.collect(Collectors.toList());
		tokenProcessor.accept(documentID, normalizedTokens);
	}

	/**
	 * Returns the list of tokens found in the text.
	 * @param text to be tokenized
	 * @return tokens.
	 */
	static List<String> tokenize(String text) {
		// very limited tokenizer, punctuation followed by whitespace
		// or pure whitepace delimits tokens
		String[] tokens = text.split(("([.,?!:]\\s+)|(\\s+)"));
		return Arrays.asList(tokens);
	}

	/**
	 * Normalizes the specified term.
	 * @param term to be normalized
	 * @return normalized term.
	 */
	static String normalize(String term){
		// very limited: only lowercases the term
		return term.toLowerCase();
	}

	/**
	 * puts the document id into the postings list of each of the specified tokens (indexing)
	 * @param documentID
	 * @param normalizedTokens
	 */
	static void indexTokens(long documentID, List<String> normalizedTokens){
		// put document id for each token in corresponding postings list
		for(String term: normalizedTokens){
			if(!index.containsKey(term)){
				synchronized (index) {
					if(!index.containsKey(term))
						index.put(term, new PostingsList<>(mostfrequentwords.contains(term)));
				}
			}
			index.get(term).add(documentID);
		}
	}

	/**
	 * Returns the postings list for the specified term.
	 * For retrieving the postings list the normalized term is used.
	 * @param term of the query
	 * @return corresponding postings list
	 */
	static PostingsList<Long> query(String term){
		PostingsList<Long> p;
		return (p=index.get(normalize(term))) != null? p:new PostingsList<>();
	}

	/**
	 * Returns a list of document ids that contain all
	 * of the specified terms.
	 * @param term1 of the query
	 * @param term2 of the query
	 * @param moreTerms of the query (optional)
	 * @return doc ids that contain all terms.
	 */
	static Iterable<Long> query(String term1, String... moreTerms){
		Iterable<Long> intersection = query(term1);
		for(String t: moreTerms){
			intersection = intersect(intersection, query(t));
		}
		return intersection;
	}

	/**
	 * Intersects two sets. It is assumed that the {@link Iterable}s
	 * contain unique elements in ascending order.
	 * @param set1 of elements
	 * @param set2 of elements
	 * @return A List containing the elements of the intersection
	 * in ascending order.
	 */
	static <T extends Comparable<T>> List<T>
	intersect(Iterable<T> set1, Iterable<T> set2)
	{
		LinkedList<T> intersection = new LinkedList<>();
		Iterator<T> it1 = set1.iterator();
		Iterator<T> it2 = set2.iterator();

		// when a set is empty return right away
		if(!it1.hasNext() || !it2.hasNext())
			return intersection;

		// intersection algorithm
		T e1=null,e2=null;
		do {
			if(e1==e2 || e1.compareTo(e2)==0){
				e1=it1.next();
				e2=it2.next();
			} else if(e1.compareTo(e2) < 0){
				e1=it1.next();
			} else if(e2.compareTo(e1) < 0){
				e2=it2.next();
			}
			if(e1.compareTo(e2)==0){
				intersection.add(e1);
			}
			// continue when there are elements left in both iterators OR when
			// there are elements left in the iterator with lower current element
		} while((it1.hasNext() && it2.hasNext()) ||
				(it1.hasNext() && e1.compareTo(e2) < 0) ||
				(it2.hasNext() && e2.compareTo(e1) < 0) );
		return intersection;
	}


	/** Prints all documents corresponding to the specified ids.
	 * When maxDocs > 0 only the first maxDocs documents are printed
	 */
	static void printDocuments(Iterable<Long> docIds, int maxDocs){
		for(Long id: docIds){
			out.println(documents.get(id));
			if(--maxDocs == 0)
				break;
		}
	}

	/** prints the whole index. EXPENSIVE! */
	static void printIndex(PrintStream ps){
		index.forEach((term, p)->{
			ps.format("%s%n\t%d\t%s%n", term, p.size(), p);
		});
	}

	static void setFileoutput(File f) throws Exception {
		out = new PrintStream(f, "UTF-8");
	}




	///////////////////////////////////
	// vector stuff ///////////////////
	///////////////////////////////////

	/**
	 * Creates a new SimpleMatrix of specified dimensions, that is backed by
	 * the specified array (in row-major order). If the data array is null
	 * then a new array is allocated to back this matrix (all entries are zero then).
	 *
	 * @param nrows number of rows
	 * @param ncols number of columns
	 * @param data optional (can be null) row-major order data array for the matrix
	 * @return nrows x ncols matrix
	 *
	 * @throws IllegalArgumentException if nrows &lt; 1 or ncols &lt; 1 or when the
	 * specified data array is not null but does not have nrows*ncols length.
	 */
	public static SimpleMatrix matrix(int nrows, int ncols, double[] data){
		if(nrows < 1 )
			throw new IllegalArgumentException("number of rows has to be positive. nrows: " + nrows);
		if(ncols < 1 )
			throw new IllegalArgumentException("number of columns has to be positive. ncols: " + ncols);
		if(data == null)
			data = new double[nrows*ncols];
		else if(nrows*ncols != data.length)
			throw new IllegalArgumentException(String.format(
					"the specified dimensions do not match the length of the data. [%dx%d]=$d elements, data array length = %d", 
					nrows,ncols,ncols*nrows,data.length));

		return SimpleMatrix.wrap(DMatrixRMaj.wrap(nrows, ncols, data));
}

	/**
	 * Creates a new SimpleMatrix with 1 column and the specified number of rows
	 * (column vector). When the data array argument is not null it will be used
	 * to back the matrix, otherwise a new array will be allocated (all entries will
	 * be zero then).
	 * @param n number of elements (size of vector, number of rows)
	 * @param data optional data array for the vectors entries.
	 * @return n dimensional column vector
	 * @throws IllegalArgumentException if n &lt; 1 or when the specified data array
	 * is not null but has not length n.
	 */
	public static SimpleMatrix vector(int n, double[] data){
		return matrix(n, 1, data);
	}

	/**
	 * Creates a new column vector of the specified size, where all entries are zero.
	 * @param n number of elements (size of vector, number of rows)
	 * @return n dimensional column vector
	 * @throws IllegalArgumentException if n &lt; 1
	 */
	public static SimpleMatrix vector(int n){
		return vector(n, null);
	}

	/**
	 * Creates a new column vector of the specified size, where all entries have
	 * the specified value.
	 * @param n number of elements (size of vector, number of rows)
	 * @param value for entries of the vector
	 * @return n dimensional column vector with all entries of specified value
	 * @throws IllegalArgumentException if n &lt; 1
	 */
	public static SimpleMatrix vector(int n, double value){
		SimpleMatrix vector = vector(n);
		vector.set(value);
		return vector;
	}

	/**
	 * Normalizes the given matrix (vector) to norm=1.
	 * If the specified matrix is close to zero, a zero matrix is returned.
	 * @param m matrix to be normalized
	 * @return normalized matrix (vector)
	 */
	public static SimpleMatrix normalize(SimpleMatrix m){
		double norm = m.normF();
		return m.scale(norm < 1e-6 ? 0:1/norm);
	}

}

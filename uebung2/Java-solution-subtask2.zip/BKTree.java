package structs;


import inforet.BooleanRetrieval;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * implementation of Burkhard-Keller tree for spelling correction
 * relies on Levenshtein algorithm to measure the distance bet. 2 strings
 */
public class BKTree {

    Node root;

    public BKTree() {
        root = null;
    }

    /**
     * reads a file that has 1 word per line
     * and constructs the whole tree from that file
     * @param filename a dictionary of correct words
     */
    public void constructFromDict(String filename) {
        long start = System.currentTimeMillis();
        try (BufferedReader r = new BufferedReader(new FileReader(filename))) {
            root = new Node(r.readLine().toLowerCase()); // the first word is the root node

            String l;
            while ((l=r.readLine())!=null) {
                l = l.toLowerCase();
                Node curNode = new Node(l); // create a new node for this word

                // traverse tree till right pos for insertion is found
                Node comparisonNode = root;
                while (true) {
                    int dist = levenshtein(l, comparisonNode.word);
                    if (dist==0) break; // word already exists in the tree; do not insert again
                    if (! comparisonNode.children.containsKey(dist)) { // add new node as child of this node
                        comparisonNode.children.put(dist, curNode);
                        break;
                    } else comparisonNode = comparisonNode.children.get(dist); // continue traversal
                }
            }
            System.out.println("Constructing the tree took: "+ (System.currentTimeMillis()-start)/1000 +" second(s).");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * use a default dictionary of english to construct the tree
     */
    public void constructFromDefaultDict() {
        String filename = "res/twitter/english-words";
        constructFromDict(filename);
    }

    /**
     * fetch all words in the tree that have max dist k from string s
     * @param s e.g. a misspelled word
     * @param k max Levenshtein distance accepted
     * @return collection of words within the specified distance from s
     */
    public List<String> fetchAllWithinDist(String s, int k) {
        long start = System.currentTimeMillis();
        // list aggregate the result (close words)
        List<String> kNearest = new ArrayList<>();
        // queue needed while traversing the tree
        Queue<Node> queue = new LinkedList<>();
        queue.add(root); // start traversal from root

        while (!queue.isEmpty()) {
            Node curNode = queue.poll();
            int dist = levenshtein(curNode.word, s);
            if (dist<=k) kNearest.add(curNode.word); // add cur word if within specified distance

            // consider all children of current word within distance
            // [dist-k , dist+k]
            int from = (dist - k > 0) ? (dist - k) : 1;
            int until = dist + k;

            for (int i = from; i<=until; i++)
                if (curNode.children.containsKey(i))
                    queue.add(curNode.children.get(i));
        }

        System.out.println("Finding correct spellings took: "+ (System.currentTimeMillis()-start) +" millisecond(s).");
        return kNearest;
    }

    // measure the Levenshtein distance bet. 2 strings
    public static int levenshtein(String s1, String s2) {
        char[] w1 = s1.toCharArray();
        char[] w2 = s2.toCharArray();
        int[][] m = new int[w1.length+1][w2.length+1];

        for (int i = 0; i < m.length; i++) {
            m[i][0] = i;
        }

        for (int i = 0; i < m[0].length; i++) {
            m[0][i] = i;
        }

        for (int i = 1; i < m.length; i++) {
            for (int j = 1; j < m[i].length; j++) {
                int copyOrReplace = w1[i-1]==w2[j-1] ? 0 : m[i-1][j-1] + 1;
                m[i][j] = Math.min(m[i-1][j]+1,
                        Math.min(m[i][j-1]+1, m[i-1][j-1]+copyOrReplace));
            }
        }
        return m[w1.length][w2.length];
    }

    // demonstrates a case where correcting a user's query is very useful
    public static void main(String[] args) {

        // step 1: construct the inverted index
        String filename = "res/twitter/tweets.txt";
        BooleanRetrieval engine = new BooleanRetrieval(); // create a new instance
        engine.index(filename); // index all the documents in the indicated file

        // step 2: construct the spelling checker using BK-tree
        BKTree spellChecker = new BKTree();
        spellChecker.constructFromDefaultDict();

        // step 3: query with a misspelled word
        List<Long> badQuery = engine.query("washinton"); // misspelled query
        System.out.println("For the query washinton"+": found "+badQuery.size()+" results.");

        // step 4: search for correct candidates with max distance of 1 from the misspelled query
        List<String> corrections = spellChecker.fetchAllWithinDist("washinton", 1);
        System.out.print("Suggested corrections: ");
        corrections.forEach(s -> System.out.print(s+" "));

        // step 5: reattempt the search with the first suggested word
        List<Long> correct = engine.query(corrections.get(0)); // corrected query
        System.out.println("\nFor the query "+ corrections.get(0)+": found "+correct.size() + " results.");
    }

    /**
     * inner class representing a tree node
     * each node has:
     *  - a word (string)
     *  - children (nodes); each associated with a number
     *    that denotes its Levenshtein distance from the cur string
     */
    private class Node {

        String word;
        HashMap<Integer, Node> children; // maps from a Levenshtein dist to child node

        Node(String s) {
            word = s;
            children = new HashMap<>();
        }
    }
}
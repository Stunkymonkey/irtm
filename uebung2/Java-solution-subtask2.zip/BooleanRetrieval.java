package inforet;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * A class to perform boolean retrieval using inverted indexing
 */
public class BooleanRetrieval {

    // maps a term to a reference that holds its postings list's id and size
    Map<String, Reference> invertedIndex;
    // stores all postings lists as LinkedLists; the id of a postings list is its index in this ArrayList
    ArrayList<LinkedList<Long>> postingsLists;

    public BooleanRetrieval() {
        invertedIndex = new HashMap<>();
        postingsLists = new ArrayList<>();
    }

    /**
     * Index the documents inside the indicated file
     * Assumes each line is tab separated, at column 2 is the id, at column 5 the content of the document
     * @param filepath path to the file to be indexed
     */
    public void index(String filepath) {

        int numPostingsList = 0; // keep track of the number of postings lists created so far

        try (BufferedReader r = new BufferedReader(new FileReader(filepath))) {

            String line;
            while ((line=r.readLine())!=null) {
                String[] lineSplit = line.split("\\t");
                if (lineSplit.length!=5) continue; // skip if num cols is less than expected

                long docID = Long.parseLong(lineSplit[1]); // doc ID is at 2nd col
                String content = lineSplit[4]; // content is at 5th col
                content = content.replaceAll("\\p{Punct}", "").toLowerCase().trim(); // delete punctuation & lowercase
                if (content.isEmpty()) continue; // skip tweets with empty content

                String[] terms = content.split(" ");
                for (String term : terms) {
                    // if term seen for 1st time: store it together with a new ref + create a new list for its postings
                    if (! invertedIndex.containsKey(term)) {
                        Reference ref = new Reference(numPostingsList);
                        invertedIndex.put(term, ref);
                        postingsLists.add(numPostingsList, new LinkedList<>());
                        numPostingsList++;
                    }

                    // get id of postings list to which the term points
                    int idCorrespondingList = invertedIndex.get(term).postingsListID;
                    // insert doc ID to posting list if not already there
                    if ( postingsLists.get(idCorrespondingList).isEmpty() ||
                            postingsLists.get(idCorrespondingList).getLast() != docID)
                        postingsLists.get(idCorrespondingList).add(docID);
                }
            }

            // store the size of the posting lists inside the reference of each term
            invertedIndex.forEach( (term, ref) -> {
                int idCorrespondingList = ref.postingsListID;
                int listSize = postingsLists.get(idCorrespondingList).size();
                ref.setPostingsListSize(listSize);
            });

            // sort all postings lists in ascending order
            for (int i = 0; i < postingsLists.size(); i++)
                Collections.sort(postingsLists.get(i));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * get the ids of all documents where the queried term is mentioned
     * @param term query term
     * @return linked list with relevant documents in ascending order
     */
    public LinkedList<Long> query(String term) {
        term = term.toLowerCase();
        if (!invertedIndex.containsKey(term)) {
            System.err.println("Term not found!");
            return new LinkedList<>();
        }
        int idCorrespondingList = invertedIndex.get(term).postingsListID; // get id of the corresponding postings list
        return postingsLists.get(idCorrespondingList); // retrieve the relevant postings list
    }

    /**
     * get the ids of all documents where the queried terms are mentioned
     * @param term1 first query term,
     * @param term2 second query term
     * @return linked list with relevant documents for both queries (intersection) in ascending order
     */
    public LinkedList<Long> query(String term1, String term2) {
        term1 = term1.toLowerCase();
        term2 = term2.toLowerCase();
        if (!invertedIndex.containsKey(term1) || !invertedIndex.containsKey(term2)) {
            System.err.println("Could not find any documents containing the word "+term1+".");
            return new LinkedList<>();
        }

        // get ids of the corresponding postings lists
        int idCorrespondinglist1 = invertedIndex.get(term1).postingsListID;
        int idCorrespondinglist2 = invertedIndex.get(term2).postingsListID;
        // return the intersection of both
        return intersect(postingsLists.get(idCorrespondinglist1), postingsLists.get(idCorrespondinglist2));
    }

    // returns the intersection of 2 lists
    private static LinkedList<Long> intersect(LinkedList<Long> l1, LinkedList<Long> l2) {

        // a list to store the common documents between the two lists
        LinkedList<Long> intersection = new LinkedList<>();
        // an iterator for each of the two lists
        Iterator<Long> iter1 = l1.iterator(), iter2 = l2.iterator();
        // holders for the values the iterators will be pointing at, initially -1 (iteration not yet started)
        long cur1 = -1, cur2 = -1;
        // indicators of whether or not to advance the iterator over list 1 and over list 2 respectively
        boolean advance1 = true, advance2 = true;

        do {
           	// get next element in list if so indicated and list not empty		
			if (advance1) if (iter1.hasNext()) cur1 = iter1.next(); else break; 
            if (advance2) if (iter2.hasNext()) cur2 = iter2.next(); else break; 

            if (cur1==cur2) { // if both are the same: add value to the list; advance both pointers
                intersection.add(cur1);
                advance1=true;
                advance2=true;
            }
            // else just advance the pointer of the list whose current value is smaller
            else if (cur1<cur2) {
                advance1=true;
                advance2=false;
            }
            else {
                advance2=true;
                advance1=false;
            }
        } while (iter1.hasNext() || iter2.hasNext()); // iterate as long as lists are not empty

        return intersection;
    }

    /**
     * prints all the documents in the indicated file whose id is contained in the indicated list
     * @param filepath file with documents; format must match that of the indexed file
     * @param docIDsList a list with a number of doc ids
     */
    public static void printDocumentsByID(String filepath, List<Long> docIDsList) {
        if (docIDsList==null || docIDsList.isEmpty()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(filepath))) {

            String line;
            while ((line=r.readLine())!=null) {
                String[] lineSplit = line.split("\\t");
                if (lineSplit.length != 5) continue;
                // doc ID is at 2nd col, content at 5th col
                long docID = Long.parseLong(lineSplit[1]);
                if (docIDsList.contains(docID))
                    System.out.println(docID+ " :: "+lineSplit[4]); // print the id followed by the content
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // demonstrates how to use this class
    public static void main(String[] args) {

        String filename = "res/twitter/tweets.txt";

        BooleanRetrieval engine = new BooleanRetrieval(); // create a new instance
        engine.index(filename); // index all the documents in the indicated file
        List<Long> stuttgartBahn = engine.query("Stuttgart","Bahn"); // query
        BooleanRetrieval.printDocumentsByID(filename, stuttgartBahn); // print query results to the screen
    }

    /**
     * Inner class representing a reference of a certain term
     * to the corresponding postings list. It stores the following
     * information: a) the id of the postings list, b) its size
     */
    class Reference {

        int postingsListID, postingsListSize;

        Reference(int id) {
            postingsListID = id;
            postingsListSize = 0; // initially size of the posting list is unknown
        }

        public void setPostingsListSize(int size) {
            this.postingsListSize = size;
        }

        @Override
        public String toString() {
            return "<id="+postingsListID+", size="+postingsListSize+">";
        }
    }
}

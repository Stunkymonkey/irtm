package de.ust.ir.nbc;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class NaiveBayesClassifier {

    public static enum Scope {
        Training, Testing
    }

    private final int INDEX_GAME_TITLE = 0;     // title of the game
    private final int INDEX_CLASS = 1;          // class of review (good, bad)
    private final int INDEX_REVIEW_TITLE = 2;   // title of review
    private final int INDEX_REVIEW = 3;         // review text

    private final int INDEX_TP = 0;             // true positive
    private final int INDEX_TN = 1;             // true negative
    private final int INDEX_FP = 2;             // false positive
    private final int INDEX_FN = 3;             // false negative

    private int good_numberOfDocuments = 0;
    private int bad_numberOfDocuments = 0;

    private int good_numberOfDistinctTokens = 0;
    private int bad_numberOfDistinctTokens = 0;
	
	// class probabilities
    private float good_probability = 0f;
    private float bad_probability = 0f;
	// probabilities if term is not occurred in class
    private float good_probabilityTermNotInClass = 0f;
    private float bad_probabilityTermNotInClass = 0f;
	
	// evaluating matrix
    private int[] good_evaluationData = new int[4];
    private int[] bad_evaluationData = new int[4];

    // token ---> occurrences/probabilities
    private Map<String, DictionaryEntry> goodDictionary;
    private Map<String, DictionaryEntry> badDictionary;


    public NaiveBayesClassifier() {
        this.goodDictionary = new HashMap<String, DictionaryEntry>();
        this.badDictionary = new HashMap<String, DictionaryEntry>();
        for (int i = 0; i < good_evaluationData.length; i++) {
            good_evaluationData[i] = 0;
            bad_evaluationData[i] = 0;
        }
    }

    /* ****************************************************************************************************************
     * Public Methods
     * ************************************************************************************************************* */

    public void run(Scope scope, File file, int maxLines) {
        //
        System.out.println();
        System.out.print("########## Start " + (scope == Scope.Training ? "training" : "testing") +
                " for data file: \"" + file.getName());
        System.out.println("\" and max_lines: " + maxLines);
        if (scope == Scope.Testing) {
            System.out.printf("%17s\t%15s\t%-30s", "Class", "Predicted class", "Title");
            System.out.println();
        }
        // Scanner to read the file line by line
        Scanner scanner = null;
        int countLines = 0;
        Normalizer normalizer = new Normalizer();
        try {
            scanner = new Scanner(file);
            scanner.useDelimiter("[\\r\\n]");
            while (scanner.hasNext()) {
                // check when zu break
                if (maxLines > 0 && countLines >= maxLines) {
                    break;
                }
                // Read line
                String line = scanner.next();
                countLines++;
                try {
					// 
                    String[] review = line.split("\t", 4);
                    String[] tokens = normalizer.tokenizeAndNormalize(review[INDEX_REVIEW_TITLE] +
                            review[INDEX_REVIEW]);
                    //
                    if (scope == Scope.Training) {
                        processDataForTraining(review, tokens);
                    } else {
                        doTesting(review, tokens, countLines);
                    }
                } catch (Exception e) {
                    String errStr = String.format("Error occurred while processing line[%d][%s:%s]: %s", countLines,
                            e.getClass(), e.getMessage(), line);
                    System.err.println(errStr);
                    continue;
                }
            }
            //
            if (scope == Scope.Training) {
                calculateTrainingProbabilities();
                System.out.println("Lines readed to index: " + (countLines + 1));
                printTrainingStatistics();
                System.out.println("End of training.");
            } else {
                System.out.println();
                printTestingStatistics();
                System.out.println("End of testing.");
            }
			
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (OutOfMemoryError oome) {
            System.err.println("OutOfMemoryError occurred! Lines has been processed: " + countLines + ".");
            oome.printStackTrace();
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }

    }

    public DictionaryEntry[] getTermsWithHighestProbability(Class clazz) {
        return getTermsWithHighestProbability(clazz, -1);
    }

    public DictionaryEntry[] getTermsWithHighestProbability(Class clazz, int limit) {
        Map<String, DictionaryEntry> dictionary = clazz == Class.GOOD ? goodDictionary : badDictionary;
        limit = limit < 0 ? dictionary.size() : limit;
        return getTermsWithHighestProbability(dictionary, limit);
    }

    /* ****************************************************************************************************************
     * Private Training
     * ************************************************************************************************************* */

    private void processDataForTraining(String[] review, String[] tokens) {
        if (Class.getValueOf(review[INDEX_CLASS]) == Class.GOOD) {
            addToDictionary(goodDictionary, tokens);
            good_numberOfDocuments++;
        } else {
            addToDictionary(badDictionary, tokens);
            bad_numberOfDocuments++;
        }
    }

    private void addToDictionary(Map<String, DictionaryEntry> dictionary, String[] tokens) {
        for (String token : tokens) {
            DictionaryEntry entry = dictionary.get(token);
            if (entry == null) {
                entry = new DictionaryEntry(token);
            }
            entry.incrementOccurrences();
            dictionary.put(token, entry);
        }
    }

    private void calculateTrainingProbabilities() {
        int totalNumberOfDocuments = good_numberOfDocuments + bad_numberOfDocuments;

        good_probability = (good_numberOfDocuments * 1f) / totalNumberOfDocuments;
        bad_probability = (bad_numberOfDocuments * 1f) / totalNumberOfDocuments;

        good_numberOfDistinctTokens = goodDictionary.size();
        bad_numberOfDistinctTokens = badDictionary.size();
        int totalDistinctTokensNumber = good_numberOfDistinctTokens + bad_numberOfDistinctTokens;

        //
        calculateProbabilitiesForEachToken(goodDictionary, good_numberOfDistinctTokens, totalDistinctTokensNumber);
        calculateProbabilitiesForEachToken(badDictionary, bad_numberOfDistinctTokens, totalDistinctTokensNumber);
        //
        good_probabilityTermNotInClass = calculateTokenProbability(0, good_numberOfDistinctTokens,
                totalDistinctTokensNumber);
        bad_probabilityTermNotInClass = calculateTokenProbability(0, bad_numberOfDistinctTokens,
                totalDistinctTokensNumber);


    }

    private void calculateProbabilitiesForEachToken(Map<String, DictionaryEntry> dictionary, int
            numberOfDistinctTokens, int totalDistinctTokensNumber) {
        Iterator<String> iterator = dictionary.keySet().iterator();
        while (iterator.hasNext()) {
            String token = iterator.next();
            DictionaryEntry entry = dictionary.get(token);

            float probability = calculateTokenProbability(entry.getOccurrences(), numberOfDistinctTokens,
                    totalDistinctTokensNumber);
            entry.setProbability(probability);
        }
    }

    private float calculateTokenProbability(int occurrences, int numberOfDistinctTokens, int
            totalDistinctTokensNumber) {
        return (1f + occurrences) / (numberOfDistinctTokens + totalDistinctTokensNumber);
    }

    private float getTermProbability(Class clazz, String term) {
        DictionaryEntry entry = clazz == Class.GOOD ? goodDictionary.get(term) : badDictionary.get(term);
        if (entry == null) {
            return clazz == Class.GOOD ? good_probabilityTermNotInClass : bad_probabilityTermNotInClass;
        }
        return entry.getProbability();
    }

    private void printTrainingStatistics() {
        System.out.println("> Number of documents annotated with the class \"good\": " + good_numberOfDocuments);
        System.out.println("> Number of documents annotated with the class \"bad\": " + bad_numberOfDocuments);
        System.out.println("> Total number of documents: " + (good_numberOfDocuments + bad_numberOfDocuments));
        System.out.println();
        System.out.println("> Number of distinct tokens annotated with the class \"good\": " +
                good_numberOfDistinctTokens);
        System.out.println("> Number of distinct tokens annotated with the class \"bad\": " +
                bad_numberOfDistinctTokens);
        System.out.println("> Total number of distinct tokens: " + (good_numberOfDistinctTokens +
                bad_numberOfDistinctTokens));
        System.out.println();
        System.out.println("> Probability of the class \"good\": " + good_probability);
        System.out.println("> Probability of the class \"bad\": " + bad_probability);
    }

    private DictionaryEntry[] getTermsWithHighestProbability(Map<String, DictionaryEntry> dictionary, int limit) {
        List<DictionaryEntry> entryList = new ArrayList<DictionaryEntry>(dictionary.values());
        Collections.sort(entryList, new Comparator<DictionaryEntry>() {
            public int compare(DictionaryEntry e1, DictionaryEntry e2) {
                if (e1.getProbability() > e2.getProbability()) {
                    return -1;
                }
                if (e1.getProbability() < e2.getProbability()) {
                    return 1;
                }
                return 0;
            }
        });

        return entryList.subList(0, limit).toArray(new DictionaryEntry[limit]);
    }

    /* ****************************************************************************************************************
     * Private Testing
     * ************************************************************************************************************* */

    private void doTesting(String[] review, String[] tokens, int lineNr) {
        Class clazz = Class.getValueOf(review[INDEX_CLASS]);
        Class predictedClass = predictClassForReview(tokens);
        System.out.printf("%10d) %4s\t%-12s\t%-30s", lineNr, clazz, predictedClass, review[INDEX_GAME_TITLE]);
        System.out.println();
        if (clazz == Class.GOOD) {
            if (predictedClass == Class.GOOD) {
                good_evaluationData[INDEX_TP]++;    // is Good, pred. Good
                bad_evaluationData[INDEX_TN]++;     // is not Bad, pred. not Bad
            } else {
                good_evaluationData[INDEX_FN]++;    // is Good, pred. not Good
                bad_evaluationData[INDEX_FP]++;     // is not Bad, pred. Bad
            }
        }
        if (clazz == Class.BAD) {
            if (predictedClass == Class.BAD) {
                bad_evaluationData[INDEX_TP]++;     // is Bad, pred. Bad
                good_evaluationData[INDEX_TN]++;    // is not Good, pred. not Good
            } else {
                bad_evaluationData[INDEX_FN]++;     // is Bad, pred. not Bad
                good_evaluationData[INDEX_FP]++;    // is not Good, pred. Good
            }
        }
    }

    private Class predictClassForReview(String[] tokens) {
        float goodClassPrediction = good_probability;
        float badClassPrediction = bad_probability;
        for (String token : tokens) {
            goodClassPrediction *= getTermProbability(Class.GOOD, token);
            badClassPrediction *= getTermProbability(Class.BAD, token);
        }
        return goodClassPrediction >= badClassPrediction ? Class.GOOD : Class.BAD;
    }

    private void printTestingStatistics() {
        int sum = 0;
        for (int i = 0; i < good_evaluationData.length; i++) {
            sum += good_evaluationData[i];
        }
        System.out.println("Evaluation of the testing data: ");
        System.out.println("The sum of the evaluation data = " + sum);
        System.out.println("For class \"good\": ");
        printEvaluationTable(Class.GOOD);
        float precision = calculatePrecision(good_evaluationData);
        float recall = calculateRecall(good_evaluationData);
        float fMeasure = calculateFMeasure(precision, recall);
        System.out.println();
        System.out.println("Precision=" + precision + ", Recall=" + recall + ", F=" + fMeasure);
        System.out.println();
        System.out.println("For class \"bad\": ");
        printEvaluationTable(Class.BAD);
        precision = calculatePrecision(bad_evaluationData);
        recall = calculateRecall(bad_evaluationData);
        fMeasure = calculateFMeasure(precision, recall);
        System.out.println();
        System.out.println("Precision=" + precision + ", Recall=" + recall + ", F=" + fMeasure);
    }

    private void printEvaluationTable(Class clazz) {
        System.out.printf("| %-18s | %-10s | %-14s |", "", "is " + clazz, "is not " + clazz);
        System.out.println();
        System.out.printf("| %-18s | TP=%-7d | FP=%-11d |", "predicted " + clazz,
                clazz == Class.GOOD ? good_evaluationData[INDEX_TP] : bad_evaluationData[INDEX_TP],
                clazz == Class.GOOD ? good_evaluationData[INDEX_FP] : bad_evaluationData[INDEX_FP]);
        System.out.println();
        System.out.printf("| %-18s | FN=%-7d | TN=%-11d |", "predicted not " + clazz,
                clazz == Class.GOOD ? good_evaluationData[INDEX_FN] : bad_evaluationData[INDEX_FN],
                clazz == Class.GOOD ? good_evaluationData[INDEX_TN] : bad_evaluationData[INDEX_TN]);
        System.out.println();
    }

    private float calculatePrecision(int[] evaluationData) {
        int denominator = evaluationData[INDEX_TP] + evaluationData[INDEX_FP];
        if(denominator == 0) {
            return 0;
        }
        return (evaluationData[INDEX_TP] * 1f) / denominator;
    }

    private float calculateRecall(int[] evaluationData) {
        int denominator = evaluationData[INDEX_TP] + evaluationData[INDEX_FN];
        if(denominator == 0) {
            return 0;
        }
        return (evaluationData[INDEX_TP] * 1f) / denominator;
    }

    private float calculateFMeasure(float precision, float recall) {
        float denominator = precision + recall;
        if(denominator == 0) {
            return 0;
        }
        return (2 * precision * recall) / denominator;
    }
}

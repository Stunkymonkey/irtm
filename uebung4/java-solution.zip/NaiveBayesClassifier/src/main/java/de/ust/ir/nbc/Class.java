package de.ust.ir.nbc;

public enum Class {
    GOOD, BAD;

    public static Class getValueOf(String name) {
        if (name.equalsIgnoreCase("gut") || name.equalsIgnoreCase("good")) {
            return GOOD;
        }
        if (name.equalsIgnoreCase("schlecht") || name.equalsIgnoreCase("bad")) {
            return BAD;
        }
        throw new IllegalArgumentException("No enum constant " + Class.class.getCanonicalName() + "." + name);
    }
}

package de.ust.ir.nbc;

public class DictionaryEntry {

    private final String term;

    private int occurrences;

    private float probability;

    public DictionaryEntry(String term) {
        this.term = term;
        this.occurrences = 0;
        this.probability = 0f;
    }

    public String getTerm() {
        return term;
    }

    public int getOccurrences() {
        return occurrences;
    }

    public void setOccurrences(int occurrences) {
        this.occurrences = occurrences;
    }

    public void incrementOccurrences() {
        this.occurrences++;
    }

    public float getProbability() {
        return probability;
    }

    public void setProbability(float probability) {
        this.probability = probability;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof DictionaryEntry)) {
            return false;
        }
        DictionaryEntry entry = (DictionaryEntry) obj;
        return this.term.equals(entry.getTerm());
    }

    @Override
    public int hashCode() {
        return this.term.hashCode();
    }
}

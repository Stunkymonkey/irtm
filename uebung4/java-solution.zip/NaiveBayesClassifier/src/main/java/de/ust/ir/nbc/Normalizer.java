package de.ust.ir.nbc;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.StopFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.de.GermanAnalyzer;
import org.apache.lucene.analysis.de.GermanLightStemFilter;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.util.Version;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class Normalizer {

    private Analyzer analyzer;

    public Normalizer() {
        // uses an external library (lucene) for tokenization, removes some common English words and stop words that are
        // not usually useful for searching, removes punctuation, removes some special characters e.g. @, #
        // and converts to lower case.
        analyzer = new GermanAnalyzer();
        analyzer.setVersion(Version.LUCENE_7_1_0);
    }

    public String[] tokenizeAndNormalize(String txt) {
        List<String> terms = new ArrayList<String>();
        try {
			// German Stop Words
            CharArraySet stopWords = GermanAnalyzer.getDefaultStopSet();
            TokenStream tokenStream = analyzer.tokenStream(null, new StringReader(txt));
            tokenStream = new StopFilter(tokenStream, stopWords);
			// Stemming
			tokenStream = new GermanLightStemFilter(tokenStream);
			// tokenStream = new GermanStemFilter(tokenStream);
			// tokenStream = new GermanMinimalStemFilter(tokenStream);
			// tokenStream = new PorterStemFilter(tokenStream);
            tokenStream.reset();
			// 
            while (tokenStream.incrementToken()) {
                String term = tokenStream.getAttribute(CharTermAttribute.class).toString();
                terms.add(term);
            }
            tokenStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return terms.toArray(new String[terms.size()]);
    }
}

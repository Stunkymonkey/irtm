package de.ust.ir.nbc;

import java.io.*;

public class Application {

    public static void main(String[] args) throws FileNotFoundException {
        if (args.length != 3) {
            System.out.println("#> java -jar <program name>.jar <training_file> <testing_file> <log_file>");
            System.out.println("training_file: string, path to file contains the training data");
            System.out.println("testing_file: string, path to file contains the testing data");
            System.out.println("log_file: string, path to log file contains the results");
            System.exit(1);
        }
        //
        File fileTraining = checkFile(args[0]);
        File fileTesting = checkFile(args[1]);
        System.setOut(getPrintStream(args[2]));

        NaiveBayesClassifier naiveBayesClassifier = new NaiveBayesClassifier();
        //
        naiveBayesClassifier.run(NaiveBayesClassifier.Scope.Training, fileTraining, -1);
        printTop(naiveBayesClassifier, 100);
        //
        naiveBayesClassifier.run(NaiveBayesClassifier.Scope.Testing, fileTesting, -1);
    }

    private static PrintStream getPrintStream(String filename) throws FileNotFoundException {
        return new PrintStream(new BufferedOutputStream(new FileOutputStream(filename)), true);
    }

    private static File checkFile(String filename) {
        File file = new File(filename);
        if (!file.exists()) {
            throw new IllegalArgumentException("File doesn't exist: " + file.getName());
        }
        if (file.isDirectory()) {
            throw new IllegalArgumentException("The provided filename is a directory: " + file.getName());
        }
        return file;
    }

    private static void printTop(NaiveBayesClassifier naiveBayesClassifier, int limit) {
        for (Class clazz : Class.values()) {
            DictionaryEntry[] top = naiveBayesClassifier.getTermsWithHighestProbability(clazz, limit);
            System.out.println("Top " + limit + " Terms with the highest priority of class \"" + clazz.name() + "\":");
            System.out.printf("%10d) %-15s [%-5s, %10s]", 0, "term", "occurrences", "probability");
            System.out.println();
            for (int i = 0; i < top.length; i++) {
                DictionaryEntry entry = top[i];
                System.out.printf("%10d) %-15s [%5d, %16f]", i + 1, entry.getTerm(), entry.getOccurrences(), entry
                        .getProbability());
                System.out.println();
            }
        }
    }
}
